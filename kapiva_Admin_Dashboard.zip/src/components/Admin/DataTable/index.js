// import TableHeader from "./Header";
// import Pagination from "./Pagination";
// import Search from "./Search";
import TableHeader from '../../Admin/DataTable/Header';
import Pagination from '../../Admin/DataTable/Pagination';
import Search from '../../Admin/DataTable/Search'

export { TableHeader, Pagination, Search };
